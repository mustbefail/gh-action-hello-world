exports.helloWorld = (name = 'World') => `Hello, ${name}!`;
